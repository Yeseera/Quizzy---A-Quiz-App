package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class mathematicsQuestions extends AppCompatActivity {

    String[] question_list9 = {"If 2x-5=11 , what is the value of x ?",
            "What is the product of the first 5 prime numbers (2, 3, 5, 7, 11) ?",
            "If a right triangle has sides of length 3, 4, and 5 units, which theorem does it satisfy ?",
            "If a car travels at a speed of 60 miles per hour, how far will it travel in 5 hours ?",
            " what is 2+2+2*4?",
    };
    String[] choose_list9 = {"9", "12", "8", "7",
            "2103", "2130", "1320", "2310",
            "Euclidean theorem", "Pythagorean Theorem", "Trigonometric theorem", "Triangles theorem",
            "200", "250", "300", "350",
            "12", "24", "10", "16"
    };
    String[] correct_list9 = {"8", "2310", "Pythagorean Theorem", "300", "12"};


    TextView cpt9_question, text9_question;
    Button btn9_choose1, btn9_choose2, btn9_choose3, btn9_choose4, btn9_next;


    int currentQuestion9 = 0;
    int scorePlayer9 = 0;
    boolean isclickBtn9 = false;
    String valueChoose9 = "";
    Button btn9_click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer);

        cpt9_question = findViewById(R.id.cpt_question);
        text9_question = findViewById(R.id.text_question);

        btn9_choose1 = findViewById(R.id.btn_choose1);
        btn9_choose2 = findViewById(R.id.btn_choose2);
        btn9_choose3 = findViewById(R.id.btn_choose3);
        btn9_choose4 = findViewById(R.id.btn_choose4);
        btn9_next = findViewById(R.id.btn_next);

        findViewById(R.id.image_back).setOnClickListener(
                a -> finish()
        );
        remplirData();
        btn9_next.setOnClickListener(
                view -> {
                    if (isclickBtn9) {
                        isclickBtn9 = false;

                        if (!valueChoose9.equals(correct_list9[currentQuestion9])) {
                            Toast.makeText(mathematicsQuestions.this, "Wrong", Toast.LENGTH_LONG).show();
                            btn9_click.setBackgroundResource(R.drawable.background_btn_erreur);

                        } else {
                            Toast.makeText(mathematicsQuestions.this, "Correct", Toast.LENGTH_LONG).show();
                            btn9_click.setBackgroundResource(R.drawable.background_btn_correct);

                            scorePlayer9++;
                        }
                        new Handler().postDelayed(() -> {
                            if (currentQuestion9 != question_list9.length - 1) {
                                currentQuestion9 = currentQuestion9 + 1;
                                remplirData();
                                valueChoose9 = "";
                                btn9_choose1.setBackgroundResource(R.drawable.background_btn_choose);
                                btn9_choose2.setBackgroundResource(R.drawable.background_btn_choose);
                                btn9_choose3.setBackgroundResource(R.drawable.background_btn_choose);
                                btn9_choose4.setBackgroundResource(R.drawable.background_btn_choose);

                            } else {
                                Intent intent = new Intent(mathematicsQuestions.this, ResulteActivity.class);
                                intent.putExtra("Resute", scorePlayer9);
                                startActivity(intent);
                                finish();
                            }

                        }, 2000);

                    } else {
                        Toast.makeText(mathematicsQuestions.this, "Please select an option", Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    void remplirData() {
        cpt9_question.setText((currentQuestion9 + 1) + "/" + question_list9.length);
        text9_question.setText(question_list9[currentQuestion9]);

        btn9_choose1.setText(choose_list9[4 * currentQuestion9]);
        btn9_choose2.setText(choose_list9[4 * currentQuestion9 + 1]);
        btn9_choose3.setText(choose_list9[4 * currentQuestion9 + 2]);
        btn9_choose4.setText(choose_list9[4 * currentQuestion9 + 3]);

    }

    public void ClickChoose(View view) {
        btn9_click = (Button) view;

        if (isclickBtn9) {
            btn9_choose1.setBackgroundResource(R.drawable.background_btn_choose);
            btn9_choose2.setBackgroundResource(R.drawable.background_btn_choose);
            btn9_choose3.setBackgroundResource(R.drawable.background_btn_choose);
            btn9_choose4.setBackgroundResource(R.drawable.background_btn_choose);
        }
        chooseBtn();


    }

    void chooseBtn() {

        btn9_click.setBackgroundResource(R.drawable.background_btn_choose_color);
        isclickBtn9 = true;
        valueChoose9 = btn9_click.getText().toString();
    }
}