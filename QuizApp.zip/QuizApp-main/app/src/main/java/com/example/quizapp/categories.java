package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class categories extends AppCompatActivity {
    ImageView computerImg,generalKnowledgeImg,historyImg,mathematicsImg,backMain;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);
        computerImg = findViewById(R.id.computerImg);
        generalKnowledgeImg = findViewById(R.id.generalKnowledgeImg);
        historyImg = findViewById(R.id.historyImg);
        mathematicsImg = findViewById(R.id.mathematicsImg);
        backMain = findViewById(R.id.backMain);

        computerImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(categories.this, computerQuestions.class);
                startActivity(intent);
            }
        });

        generalKnowledgeImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(categories.this, gkQuestions.class);
                startActivity(intent);
            }
        });

        historyImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(categories.this, historyQuestions.class);
                startActivity(intent);
            }
        });

        mathematicsImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(categories.this, mathematicsQuestions.class);
                startActivity(intent);
            }
        });

        backMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(categories.this, MainActivity.class);
                startActivity(intent);
            }
        });




    }
}