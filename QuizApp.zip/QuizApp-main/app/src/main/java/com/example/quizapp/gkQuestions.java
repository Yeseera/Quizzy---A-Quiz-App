package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class gkQuestions extends AppCompatActivity {


    String[] question_list2 = {"Which city is the capital city of India? ",
            "Who painted the Mona Lisa ?",
            "Who invented light bulb ?",
            "Which planet is known as the 'Red Planet' ?",
            "Who is the author of the play 'Romeo and Juliet'?",
            " Which country is known as the Land of the Rising Sun ?",
            "Which is the tallest mountain in the world ?"};
    String[] choose_list2 = {"India ","Bangalore","Delhi","Karnataka",
            "Leonardo da Vinci","Vincent van Gogh","Pablo Picasso","Michelangelo",
            "Thomas Edison","Glen Maxwell","Issac Newton","Alexander Grahambell",
            "Mercury","Jupiter","Earth","Mars",
            "William Shakespeare", "Jane Austen", "Charles Dickens", "Mark Twain" ,
            "China", "Japan","South Korea", "Vietnam",
            "Mount Kilimanjaro","Mount Everest","K2","Mount Fuji"};
    String[] correct_list2 = {"Delhi","Leonardo da Vinci","Thomas Edison","Mars","William Shakespeare","Japan"
            ,"Mount Everest"};


    TextView cpt2_question , text2_question;
    Button btn2_choose1 , btn2_choose2 , btn2_choose3 , btn2_choose4 , btn2_next;





    int currentQuestion2 =  0  ;
    int scorePlayer2 =  0  ;
    boolean isclickBtn2 = false;
    String valueChoose2 = "";
    Button btn2_click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer);
        cpt2_question = findViewById(R.id.cpt_question);
        text2_question = findViewById(R.id.text_question);

        btn2_choose1 = findViewById(R.id.btn_choose1);
        btn2_choose2 = findViewById(R.id.btn_choose2);
        btn2_choose3 = findViewById(R.id.btn_choose3);
        btn2_choose4 = findViewById(R.id.btn_choose4);
        btn2_next = findViewById(R.id.btn_next);

        findViewById(R.id.image_back).setOnClickListener(
                a-> finish()
        );
        remplirData();
        btn2_next.setOnClickListener(
                view -> {
                    if (isclickBtn2){
                        isclickBtn2 = false;

                        if(!valueChoose2.equals(correct_list2[currentQuestion2])){
                            Toast.makeText(gkQuestions.this , "Wrong",Toast.LENGTH_LONG).show();
                            btn2_click.setBackgroundResource(R.drawable.background_btn_erreur);

                        }else {
                            Toast.makeText(gkQuestions.this , "Correct",Toast.LENGTH_LONG).show();
                            btn2_click.setBackgroundResource(R.drawable.background_btn_correct);

                            scorePlayer2++;
                        }
                        new Handler().postDelayed(() -> {
                            if(currentQuestion2!=question_list2.length-1){
                                currentQuestion2 = currentQuestion2 + 1;
                                remplirData();
                                valueChoose2 = "";
                                btn2_choose1.setBackgroundResource(R.drawable.background_btn_choose);
                                btn2_choose2.setBackgroundResource(R.drawable.background_btn_choose);
                                btn2_choose3.setBackgroundResource(R.drawable.background_btn_choose);
                                btn2_choose4.setBackgroundResource(R.drawable.background_btn_choose);

                            }else {
                                Intent intent  = new Intent(gkQuestions.this , ResulteActivity.class);
                                intent.putExtra("Resute" , scorePlayer2);
                                startActivity(intent);
                                finish();
                            }

                        },2000);

                    }else {
                        Toast.makeText(gkQuestions.this ,  "Please select an option",Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    void remplirData(){
        cpt2_question.setText((currentQuestion2+1) + "/" + question_list2.length);
        text2_question.setText(question_list2[currentQuestion2]);

        btn2_choose1.setText(choose_list2[4 * currentQuestion2]);
        btn2_choose2.setText(choose_list2[4 * currentQuestion2+1]);
        btn2_choose3.setText(choose_list2[4 * currentQuestion2+2]);
        btn2_choose4.setText(choose_list2[4 * currentQuestion2+3]);

    }

    public void ClickChoose(View view) {
        btn2_click = (Button)view;

        if (isclickBtn2) {
            btn2_choose1.setBackgroundResource(R.drawable.background_btn_choose);
            btn2_choose2.setBackgroundResource(R.drawable.background_btn_choose);
            btn2_choose3.setBackgroundResource(R.drawable.background_btn_choose);
            btn2_choose4.setBackgroundResource(R.drawable.background_btn_choose);
        }
        chooseBtn();


    }
    void chooseBtn(){

        btn2_click.setBackgroundResource(R.drawable.background_btn_choose_color);
        isclickBtn2 = true;
        valueChoose2 = btn2_click.getText().toString();
    }
}