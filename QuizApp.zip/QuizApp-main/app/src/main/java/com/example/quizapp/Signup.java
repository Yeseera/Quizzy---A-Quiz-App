package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Signup extends AppCompatActivity {
    EditText username,password,confirmpwd;
    Button signup;
    TextView subottomline;

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        db = new Database(this);
        username = findViewById(R.id.username);
        password=findViewById(R.id.password);
        confirmpwd = findViewById(R.id.confirmpwd);
        signup= findViewById(R.id.signup);
        subottomline = findViewById(R.id.subottomline);

        subottomline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Signup.this, Login.class));
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String confirmpassswd = confirmpwd.getText().toString();


                if (user.equals("")|| pass.equals("")|| confirmpassswd.equals(""))
                    Toast.makeText(Signup.this,"all fields are mandatory",Toast.LENGTH_SHORT).show();
                else  {
                    if (pass.equals(confirmpassswd)){
                        Boolean checkusername = db.checkusername(user);
                        if (! checkusername){
                            Boolean insert = db.insertData(user,pass);
                            if (insert){
                                Toast.makeText(Signup.this,"signup Successful",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), Login.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Signup.this,"signup Failed",Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast .makeText(Signup.this,"User already exists; please login",Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Signup.this,"Invalid password",Toast.LENGTH_SHORT).show();






                    }
                }
            }

        });

    }
    public static boolean isValid(String passwordhere){
        int f1 = 0, f2 = 0, f3 = 0;
        if (passwordhere.length() < 8) {
            return false;
        } else {
            for (int p = 0; p < passwordhere.length(); p++) {
                if (Character.isLetter(passwordhere.charAt(p))) {
                    f1 = 1;
                }
            }
            for (int r = 0; r < passwordhere.length(); r++) {
                if (Character.isLetter(passwordhere.charAt(r))) {
                    f2 = 1;
                }
            }
            for (int s = 0; s < passwordhere.length(); s++) {
                if (Character.isLetter(passwordhere.charAt(s))) {
                    f3 = 1;
                }
            }
            if (f1 == 1 && f2 == 1 && f3 == 1)
                return true;
            return false;

        }
    }
}





















