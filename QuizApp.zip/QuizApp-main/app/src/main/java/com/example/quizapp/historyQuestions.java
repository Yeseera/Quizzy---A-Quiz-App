package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class historyQuestions extends AppCompatActivity {


    String[] question_list8 = {"The Taj Mahal, a UNESCO World Heritage Site, is located in which Indian city?",
            "Who was the first woman Prime Minister of India? ?",
            "The ancient university of Nalanda was located in which present-day state of India??",
            "The Jallianwala Bagh massacre occurred in which city of India??",
            "Which Mughal emperor built the Red Fort in Delhi? ?",
            "'The Dandi March' was led by whom?",
            "Who was the first woman President of India?"
    };
    String[] choose_list8 = {"Mumbai", "Agra", "Delhi", "India",
            "Indira Gandhi", "Sonia Gandhi", "Razia Sultan", "Mother Teresa",
            "Karnataka", "Uttar Pradesh", "Bihar", "Madhya Pradesh",
            "Amritsar", "Pune", "Delhi", "Mumbai",
            "Akbar", "Babar", "Shah Jahan", "Aurangazeb",
            "Bhagat Singh", "Jawaharlal Nehru", "Mahatma Gandhi", "Subhash Chandra Bose",
            "Indira Gandhi","Sonia Gandhi","Pratibha Patil","Sarojini Naidu"
    };
    String[] correct_list8 = {"Agra", "Indira Gandhi", "Bihar", "Amritsar", "Shah Jahan", "Mahatma Gandhi","Pratibha Patil"};


    TextView cpt8_question, text8_question;
    Button btn8_choose1, btn8_choose2, btn8_choose3, btn8_choose4, btn8_next;


    int currentQuestion8 = 0;
    int scorePlayer8 = 0;
    boolean isclickBtn8 = false;
    String valueChoose8 = "";
    Button btn8_click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer);

        cpt8_question = findViewById(R.id.cpt_question);
        text8_question = findViewById(R.id.text_question);

        btn8_choose1 = findViewById(R.id.btn_choose1);
        btn8_choose2 = findViewById(R.id.btn_choose2);
        btn8_choose3 = findViewById(R.id.btn_choose3);
        btn8_choose4 = findViewById(R.id.btn_choose4);
        btn8_next = findViewById(R.id.btn_next);

        findViewById(R.id.image_back).setOnClickListener(
                a -> finish()
        );
        remplirData();
        btn8_next.setOnClickListener(
                view -> {
                    if (isclickBtn8) {
                        isclickBtn8 = false;

                        if (!valueChoose8.equals(correct_list8[currentQuestion8])) {
                            Toast.makeText(historyQuestions.this, "Wrong", Toast.LENGTH_LONG).show();
                            btn8_click.setBackgroundResource(R.drawable.background_btn_erreur);

                        } else {
                            Toast.makeText(historyQuestions.this, "Correct", Toast.LENGTH_LONG).show();
                            btn8_click.setBackgroundResource(R.drawable.background_btn_correct);

                            scorePlayer8++;
                        }
                        new Handler().postDelayed(() -> {
                            if (currentQuestion8 != question_list8.length - 1) {
                                currentQuestion8 = currentQuestion8 + 1;
                                remplirData();
                                valueChoose8 = "";
                                btn8_choose1.setBackgroundResource(R.drawable.background_btn_choose);
                                btn8_choose2.setBackgroundResource(R.drawable.background_btn_choose);
                                btn8_choose3.setBackgroundResource(R.drawable.background_btn_choose);
                                btn8_choose4.setBackgroundResource(R.drawable.background_btn_choose);

                            } else {
                                Intent intent = new Intent(historyQuestions.this, ResulteActivity.class);
                                intent.putExtra("Resute", scorePlayer8);
                                startActivity(intent);
                                finish();
                            }

                        }, 2000);

                    } else {
                        Toast.makeText(historyQuestions.this, "Please select an option", Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    void remplirData() {
        cpt8_question.setText((currentQuestion8 + 1) + "/" + question_list8.length);
        text8_question.setText(question_list8[currentQuestion8]);

        btn8_choose1.setText(choose_list8[4 * currentQuestion8]);
        btn8_choose2.setText(choose_list8[4 * currentQuestion8 + 1]);
        btn8_choose3.setText(choose_list8[4 * currentQuestion8 + 2]);
        btn8_choose4.setText(choose_list8[4 * currentQuestion8 + 3]);

    }

    public void ClickChoose(View view) {
        btn8_click = (Button) view;

        if (isclickBtn8) {
            btn8_choose1.setBackgroundResource(R.drawable.background_btn_choose);
            btn8_choose2.setBackgroundResource(R.drawable.background_btn_choose);
            btn8_choose3.setBackgroundResource(R.drawable.background_btn_choose);
            btn8_choose4.setBackgroundResource(R.drawable.background_btn_choose);
        }
        chooseBtn();


    }

    void chooseBtn() {

        btn8_click.setBackgroundResource(R.drawable.background_btn_choose_color);
        isclickBtn8 = true;
        valueChoose8 = btn8_click.getText().toString();
    }
}