package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Login extends AppCompatActivity {
    EditText username, password;
    Button loginbtn;

    TextView loginbottomline, fpassword;
    Database db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new Database(this);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginbtn = findViewById(R.id.loginbtn);
        loginbottomline = findViewById(R.id.loginbottomline);
        fpassword = findViewById(R.id.fpassword);

        loginbottomline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login.this, Signup.class));
            }
        });

        fpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Login.this,"Please Sign up Again",Toast.LENGTH_SHORT).show();
            }
        });


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();


                if (user.equals("") || pass.equals(""))
                    Toast.makeText(Login.this, "login successful", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkCredentials = db.checkusernamepassword(user,pass);
                    if (checkCredentials) {
                        Toast.makeText(Login.this,"Login successful",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(Login.this,"Invalid Credentials",Toast.LENGTH_SHORT).show();

                    }
                }

            }

        } );
    }

}



























